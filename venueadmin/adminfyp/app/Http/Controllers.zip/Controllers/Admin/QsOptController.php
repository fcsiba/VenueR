<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\QsOpt\BulkDestroyQsOpt;
use App\Http\Requests\Admin\QsOpt\DestroyQsOpt;
use App\Http\Requests\Admin\QsOpt\IndexQsOpt;
use App\Http\Requests\Admin\QsOpt\StoreQsOpt;
use App\Http\Requests\Admin\QsOpt\UpdateQsOpt;
use App\Models\QsOpt;
use App\Models\SurveyQ;
use Brackets\AdminListing\Facades\AdminListing;
use Exception;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class QsOptController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @param IndexQsOpt $request
     * @return array|Factory|View
     */
    public function index(IndexQsOpt $request)
    {
        // create and AdminListing instance for a specific model and
        $data = AdminListing::create(QsOpt::class)->processRequestAndGet(
            // pass the request with params
            $request,

            // set columns to query
            ['id', 'qs_id', 'minimum', 'maximum'],

            // set columns to searchIn
            ['id', 'title', 'sub_text']
        );

        if ($request->ajax()) {
            if ($request->has('bulk')) {
                return [
                    'bulkItems' => $data->pluck('id')
                ];
            }
            return ['data' => $data];
        }

        return view('admin.qs-opt.index', ['data' => $data]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @throws AuthorizationException
     * @return Factory|View
     */
    public function create(SurveyQ $qsOpt)
    {

        $this->authorize('admin.qs-opt.create');

        return view('admin.qs-opt.create', ['qs' => $qsOpt]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreQsOpt $request
     * @return array|RedirectResponse|Redirector
     */
    public function store(int $id,StoreQsOpt $request)
    {
        // Sanitize input
        $sanitized = $request->getSanitized();

        // Store the QsOpt
        $qsOpt = QsOpt::create($sanitized);
    
        DB::table('qs_opt')
            ->where('id',$qsOpt->id)
            ->update([
                'qs_id' => $id,
            ]);
        if ($request->ajax()) {
            return ['redirect' => url('admin/survey-qs/'.$id.'/view_opt'), 'message' => trans('brackets/admin-ui::admin.operation.succeeded')];
        }

        return redirect('admin/survey-qs/22/view_opt');
    }

    /**
     * Display the specified resource.
     *
     * @param QsOpt $qsOpt
     * @throws AuthorizationException
     * @return void
     */
    public function show(QsOpt $qsOpt)
    {
        $this->authorize('admin.qs-opt.show', $qsOpt);

        // TODO your code goes here
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param QsOpt $qsOpt
     * @throws AuthorizationException
     * @return Factory|View
     */
    public function edit(QsOpt $qsOpt)
    {
        $this->authorize('admin.qs-opt.edit', $qsOpt);


        return view('admin.qs-opt.edit', [
            'qsOpt' => $qsOpt,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateQsOpt $request
     * @param QsOpt $qsOpt
     * @return array|RedirectResponse|Redirector
     */
    public function update(UpdateQsOpt $request, QsOpt $qsOpt)
    {
        // Sanitize input
        $sanitized = $request->getSanitized();

        // Update changed values QsOpt
        $qsOpt->update($sanitized);

        if ($request->ajax()) {
            return [
                'redirect' => url('admin/survey-qs/'.$qsOpt->qs_id.'/view_opt'),
                'message' => trans('brackets/admin-ui::admin.operation.succeeded'),
            ];
        }

        return redirect('admin/survey-qs/'.$qsOpt->qs_id.'/view_opt');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param DestroyQsOpt $request
     * @param QsOpt $qsOpt
     * @throws Exception
     * @return ResponseFactory|RedirectResponse|Response
     */
    public function destroy(DestroyQsOpt $request, QsOpt $qsOpt)
    {
        $qsOpt->delete();

        if ($request->ajax()) {
            return response(['message' => trans('brackets/admin-ui::admin.operation.succeeded')]);
        }

        return redirect()->back();
    }

    /**
     * Remove the specified resources from storage.
     *
     * @param BulkDestroyQsOpt $request
     * @throws Exception
     * @return Response|bool
     */
    public function bulkDestroy(BulkDestroyQsOpt $request): Response
    {
        DB::transaction(static function () use ($request) {
            collect($request->data['ids'])
                ->chunk(1000)
                ->each(static function ($bulkChunk) {
                    QsOpt::whereIn('id', $bulkChunk)->delete();

                    // TODO your code goes here
                });
        });

        return response(['message' => trans('brackets/admin-ui::admin.operation.succeeded')]);
    }
}
