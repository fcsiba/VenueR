<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\SurveyQ\BulkDestroySurveyQ;
use App\Http\Requests\Admin\SurveyQ\DestroySurveyQ;
use App\Http\Requests\Admin\SurveyQ\IndexSurveyQ;
use App\Http\Requests\Admin\SurveyQ\StoreSurveyQ;
use App\Http\Requests\Admin\SurveyQ\UpdateSurveyQ;
use App\Models\Category;
use App\Models\QsOpt;
use App\Models\Qstype;
use App\Models\Survey;
use App\Models\SurveyQ;
use Brackets\AdminListing\Facades\AdminListing;
use Exception;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class SurveyQSController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @param IndexSurveyQ $request
     * @return array|Factory|View
     */
    public function index(IndexSurveyQ $request)
    {
        $social = SurveyQ::where('cat', 1)->get();
        $forex = SurveyQ::where('cat', 2)->get();
        $course = SurveyQ::where('cat', 3)->get();
        $business = SurveyQ::where('cat', 4)->get();
        $home = SurveyQ::where('cat', 5)->get();

        return view('admin.survey-q.index', ['social' => $social, 'forex' => $forex, 'course' => $course, 'business' => $business,'home'=>$home]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @throws AuthorizationException
     * @return Factory|View
     */
    public function create()
    {
        $this->authorize('admin.survey-q.create');
        $cat = Category::all();
        $categories = [];
        foreach ($cat as $item) {
            $categories[$item->id] = $item->name;
        }
        $qstype = Qstype::all();
        $type = [];
        foreach ($qstype as $item) {
            $type[$item->id] = $item->qs_type;
        }

        return view('admin.survey-q.create', ['cat' => $categories, 'qstype' => $type]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreSurveyQ $request
     * @return array|RedirectResponse|Redirector
     */
    public function store(StoreSurveyQ $request)
    {
        // Sanitize input
        $sanitized = $request->getSanitized();

        // Store the SurveyQ
        $surveyQ = SurveyQ::create($sanitized);

        if ($request->ajax()) {
            return ['redirect' => url('admin/survey-qs'), 'message' => trans('brackets/admin-ui::admin.operation.succeeded')];
        }

        return redirect('admin/survey-qs');
    }

    /**
     * Display the specified resource.
     *
     * @param SurveyQ $surveyQ
     * @throws AuthorizationException
     * @return void
     */
    public function show(SurveyQ $surveyQ)
    {
        $this->authorize('admin.survey-q.show', $surveyQ);

        // TODO your code goes here
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param SurveyQ $surveyQ
     * @throws AuthorizationException
     * @return Factory|View
     */
    public function view_opt(SurveyQ $surveyQ)
    {
        $options = QsOpt::where('qs_id', $surveyQ->id)->get();
        return view('admin.qs-opt.index', [
            'options' => $options, 'survey' => $surveyQ
        ]);
    }

    public function edit(SurveyQ $surveyQ)
    {
        $this->authorize('admin.survey-q.edit', $surveyQ);
        $cat = Category::all();
        $categories = [];
        foreach ($cat as $item) {
            $categories[$item->id] = $item->name;
        }
        $qstype = Qstype::all();
        $type = [];
        foreach ($qstype as $item) {
            $type[$item->id] = $item->qs_type;
        }
        $chk = Survey::where('qs_id', $surveyQ->id)->get();

        return view('admin.survey-q.edit', [
            'surveyQ' => $surveyQ, 'cat' => $categories, 'qstype' => $type, 'chk' => $chk
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateSurveyQ $request
     * @param SurveyQ $surveyQ
     * @return array|RedirectResponse|Redirector
     */
    public function update(UpdateSurveyQ $request, SurveyQ $surveyQ)
    {
        // Sanitize input
        $sanitized = $request->getSanitized();

        // Update changed values SurveyQ
        $surveyQ->update($sanitized);

        if ($request->ajax()) {
            return [
                'redirect' => url('admin/survey-qs'),
                'message' => trans('brackets/admin-ui::admin.operation.succeeded'),
            ];
        }

        return redirect('admin/survey-qs');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param DestroySurveyQ $request
     * @param SurveyQ $surveyQ
     * @throws Exception
     * @return ResponseFactory|RedirectResponse|Response
     */
    public function destroy(DestroySurveyQ $request, SurveyQ $surveyQ)
    {
        $surveyQ->delete();

        if ($request->ajax()) {
            return response(['message' => trans('brackets/admin-ui::admin.operation.succeeded')]);
        }

        return redirect()->back();
    }

    /**
     * Remove the specified resources from storage.
     *
     * @param BulkDestroySurveyQ $request
     * @throws Exception
     * @return Response|bool
     */
    public function bulkDestroy(BulkDestroySurveyQ $request): Response
    {
        DB::transaction(static function () use ($request) {
            collect($request->data['ids'])
                ->chunk(1000)
                ->each(static function ($bulkChunk) {
                    SurveyQ::whereIn('id', $bulkChunk)->delete();

                    // TODO your code goes here
                });
        });

        return response(['message' => trans('brackets/admin-ui::admin.operation.succeeded')]);
    }
}
