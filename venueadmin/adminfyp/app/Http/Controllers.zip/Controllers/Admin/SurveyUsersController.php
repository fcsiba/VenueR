<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\SurveyUser\BulkDestroySurveyUser;
use App\Http\Requests\Admin\SurveyUser\DestroySurveyUser;
use App\Http\Requests\Admin\SurveyUser\IndexSurveyUser;
use App\Http\Requests\Admin\SurveyUser\StoreSurveyUser;
use App\Http\Requests\Admin\SurveyUser\UpdateSurveyUser;
use App\Models\Survey;
use App\Models\SurveyUser;
use Brackets\AdminListing\Facades\AdminListing;
use Exception;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class SurveyUsersController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @param IndexSurveyUser $request
     * @return array|Factory|View
     */
    public function index(IndexSurveyUser $request)
    {
        // create and AdminListing instance for a specific model and
        $data = AdminListing::create(SurveyUser::class)->processRequestAndGet(
            // pass the request with params
            $request,

            // set columns to query
            ['id', 'name', 'email', 'phone'],

            // set columns to searchIn
            ['id', 'name', 'email', 'phone']
        );

        if ($request->ajax()) {
            if ($request->has('bulk')) {
                return [
                    'bulkItems' => $data->pluck('id')
                ];
            }
            return ['data' => $data];
        }
        $social=Survey::join('survey_q_s', 'survey_q_s.id', '=', 'survey.qs_id')
        ->where('survey_q_s.cat', '=', '1')->get();
        $business=Survey::join('survey_q_s', 'survey_q_s.id', '=', 'survey.qs_id')
        ->where('survey_q_s.cat', '=', '4')->get();
        $forex=Survey::join('survey_q_s', 'survey_q_s.id', '=', 'survey.qs_id')
        ->where('survey_q_s.cat', '=', '2')->get();
        $courses=Survey::join('survey_q_s', 'survey_q_s.id', '=', 'survey.qs_id')
        ->where('survey_q_s.cat', '=', '3')->get();
        return view('admin.survey-user.index', ['data' => $data,'social'=>$social,'business'=>$business,'forex'=>$forex,'courses'=>$courses]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @throws AuthorizationException
     * @return Factory|View
     */
    public function create()
    {
        $this->authorize('admin.survey-user.create');

        return view('admin.survey-user.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreSurveyUser $request
     * @return array|RedirectResponse|Redirector
     */
    public function store(StoreSurveyUser $request)
    {
        // Sanitize input
        $sanitized = $request->getSanitized();

        // Store the SurveyUser
        $surveyUser = SurveyUser::create($sanitized);

        if ($request->ajax()) {
            return ['redirect' => url('admin/survey-users'), 'message' => trans('brackets/admin-ui::admin.operation.succeeded')];
        }

        return redirect('admin/survey-users');
    }

    /**
     * Display the specified resource.
     *
     * @param SurveyUser $surveyUser
     * @throws AuthorizationException
     * @return void
     */
    public function show(SurveyUser $surveyUser)
    {
        $this->authorize('admin.survey-user.show', $surveyUser);

        // TODO your code goes here
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param SurveyUser $surveyUser
     * @throws AuthorizationException
     * @return Factory|View
     */
    public function edit(SurveyUser $surveyUser)
    {
        $this->authorize('admin.survey-user.edit', $surveyUser);


        return view('admin.survey-user.edit', [
            'surveyUser' => $surveyUser,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateSurveyUser $request
     * @param SurveyUser $surveyUser
     * @return array|RedirectResponse|Redirector
     */
    public function update(UpdateSurveyUser $request, SurveyUser $surveyUser)
    {
        // Sanitize input
        $sanitized = $request->getSanitized();

        // Update changed values SurveyUser
        $surveyUser->update($sanitized);

        if ($request->ajax()) {
            return [
                'redirect' => url('admin/survey-users'),
                'message' => trans('brackets/admin-ui::admin.operation.succeeded'),
            ];
        }

        return redirect('admin/survey-users');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param DestroySurveyUser $request
     * @param SurveyUser $surveyUser
     * @throws Exception
     * @return ResponseFactory|RedirectResponse|Response
     */
    public function destroy(DestroySurveyUser $request, SurveyUser $surveyUser)
    {
        $surveyUser->delete();

        if ($request->ajax()) {
            return response(['message' => trans('brackets/admin-ui::admin.operation.succeeded')]);
        }

        return redirect()->back();
    }

    /**
     * Remove the specified resources from storage.
     *
     * @param BulkDestroySurveyUser $request
     * @throws Exception
     * @return Response|bool
     */
    public function bulkDestroy(BulkDestroySurveyUser $request) : Response
    {
        DB::transaction(static function () use ($request) {
            collect($request->data['ids'])
                ->chunk(1000)
                ->each(static function ($bulkChunk) {
                    SurveyUser::whereIn('id', $bulkChunk)->delete();

                    // TODO your code goes here
                });
        });

        return response(['message' => trans('brackets/admin-ui::admin.operation.succeeded')]);
    }
}
