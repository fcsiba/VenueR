<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\General\BulkDestroyGeneral;
use App\Http\Requests\Admin\General\DestroyGeneral;
use App\Http\Requests\Admin\General\IndexGeneral;
use App\Http\Requests\Admin\General\StoreGeneral;
use App\Http\Requests\Admin\General\UpdateGeneral;
use App\Models\General;
use Brackets\AdminListing\Facades\AdminListing;
use Exception;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class GeneralController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @param IndexGeneral $request
     * @return array|Factory|View
     */
    public function index(IndexGeneral $request)
    {
        // create and AdminListing instance for a specific model and

        $sector = General::all();
        return view('admin.general.index', ['sector' => $sector]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @throws AuthorizationException
     * @return Factory|View
     */
    public function create()
    {
        $this->authorize('admin.general.create');

        return view('admin.general.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreGeneral $request
     * @return array|RedirectResponse|Redirector
     */
    public function store(Request $request)
    {
        // Sanitize input

        //$sanitized = $request->getSanitized();
        // Store the General
        //$a=$request->file('gallery');
        $fl_store = "";
        //$general = General::create($sanitized);
        if ($request->hasFile('image')) {
            $nmwithex = $request->file('image')->getClientOriginalName();
            $filename = pathinfo($nmwithex, PATHINFO_FILENAME);
            $ext = $request->file('image')->getClientOriginalExtension();
            $fl_store = $filename . time() . '.' . $ext;
            $path = $request->file('image')->storeAs('public/img', $fl_store);
        }
        $general = new General();
        $general->h1 = $request->input('h1');
        $general->sub_text = $request->input('sub_text');
        $general->href = $request->input('href');
        $general->save();
        /* $mediaItems = $general->getMedia('gallery'); */
        //$publicUrl = $mediaItems[0]->getUrl();
        DB::table('general')
            ->where('id', $general->id)
            ->update([
                'sector_name' => "Sectors",
                'image' => $fl_store
            ]);

        if ($request->ajax()) {
            return ['redirect' => url('admin/generals'), 'message' => trans('brackets/admin-ui::admin.operation.succeeded')];
        }

        return redirect('admin/generals');
    }

    /**
     * Display the specified resource.
     *
     * @param General $general
     * @throws AuthorizationException
     * @return void
     */
    public function show(General $general)
    {
        $this->authorize('admin.general.show', $general);

        // TODO your code goes here
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param General $general
     * @throws AuthorizationException
     * @return Factory|View
     */
    public function edit(General $general)
    {
        $this->authorize('admin.general.edit', $general);


        return view('admin.general.edit', [
            'general' => $general,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateGeneral $request
     * @param General $general
     * @return array|RedirectResponse|Redirector
     */
    public function update(Request $request, General $general)
    {
        // Sanitize input
        //$sanitized = $request->getSanitized();

        // Update changed values General
        //$general->update($sanitized);
        $fl_store = "";
        //$general = General::create($sanitized);
        if ($request->hasFile('image')) {
            $nmwithex = $request->file('image')->getClientOriginalName();
            $filename = pathinfo($nmwithex, PATHINFO_FILENAME);
            $ext = $request->file('image')->getClientOriginalExtension();
            $fl_store = $filename . time() . '.' . $ext;
            $path = $request->file('image')->storeAs('public/img', $fl_store);
            DB::table('general')
                ->where('id', $request->input('id'))
                ->update([
                    'image' => $fl_store
                ]);
        }
        DB::table('general')
            ->where('id', $request->input('id'))
            ->update([
                'h1' => $request->input('h1'),
                'sub_text' => $request->input('sub_text'),
                'href' => $request->input('href')
            ]);

        if ($request->ajax()) {
            return [
                'redirect' => url('admin/generals'),
                'message' => trans('brackets/admin-ui::admin.operation.succeeded'),
            ];
        }

        return redirect('admin/generals');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param DestroyGeneral $request
     * @param General $general
     * @throws Exception
     * @return ResponseFactory|RedirectResponse|Response
     */
    public function destroy(DestroyGeneral $request, General $general)
    {
        $general->delete();

        if ($request->ajax()) {
            return response(['message' => trans('brackets/admin-ui::admin.operation.succeeded')]);
        }

        return redirect()->back();
    }

    /**
     * Remove the specified resources from storage.
     *
     * @param BulkDestroyGeneral $request
     * @throws Exception
     * @return Response|bool
     */
    public function bulkDestroy(BulkDestroyGeneral $request): Response
    {
        DB::transaction(static function () use ($request) {
            collect($request->data['ids'])
                ->chunk(1000)
                ->each(static function ($bulkChunk) {
                    General::whereIn('id', $bulkChunk)->delete();

                    // TODO your code goes here
                });
        });

        return response(['message' => trans('brackets/admin-ui::admin.operation.succeeded')]);
    }
}
