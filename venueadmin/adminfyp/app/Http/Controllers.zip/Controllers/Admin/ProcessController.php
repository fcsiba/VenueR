<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Process\BulkDestroyProcess;
use App\Http\Requests\Admin\Process\DestroyProcess;
use App\Http\Requests\Admin\Process\IndexProcess;
use App\Http\Requests\Admin\Process\StoreProcess;
use App\Http\Requests\Admin\Process\UpdateProcess;
use App\Models\Process;
use Brackets\AdminListing\Facades\AdminListing;
use Exception;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class ProcessController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @param IndexProcess $request
     * @return array|Factory|View
     */
    public function index(IndexProcess $request)
    {
        $data = Process::all();
        $section = [];
        $section[0] = "Header";
        $section[1] = "Footer";
        $section[2] = "Survey Details";
        $section[3] = "Hey User";
        $section[4] = "Thank you";

        return view('admin.process.index', ['data' => $data, 'section' => $section]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @throws AuthorizationException
     * @return Factory|View
     */
    public function create()
    {
        $this->authorize('admin.process.create');

        return view('admin.process.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreProcess $request
     * @return array|RedirectResponse|Redirector
     */
    public function store(StoreProcess $request)
    {
        // Sanitize input
        $sanitized = $request->getSanitized();

        // Store the Process
        $process = Process::create($sanitized);

        if ($request->ajax()) {
            return ['redirect' => url('admin/processes'), 'message' => trans('brackets/admin-ui::admin.operation.succeeded')];
        }

        return redirect('admin/processes');
    }

    /**
     * Display the specified resource.
     *
     * @param Process $process
     * @throws AuthorizationException
     * @return void
     */
    public function show(Process $process)
    {
        $this->authorize('admin.process.show', $process);

        // TODO your code goes here
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Process $process
     * @throws AuthorizationException
     * @return Factory|View
     */
    public function edit(Process $process)
    {
        $this->authorize('admin.process.edit', $process);


        return view('admin.process.edit', [
            'process' => $process,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateProcess $request
     * @param Process $process
     * @return array|RedirectResponse|Redirector
     */
    public function update(UpdateProcess $request, Process $process)
    {
        // Sanitize input
        $sanitized = $request->getSanitized();

        // Update changed values Process
        $process->update($sanitized);

        if ($request->ajax()) {
            return [
                'redirect' => url('admin/processes'),
                'message' => trans('brackets/admin-ui::admin.operation.succeeded'),
            ];
        }

        return redirect('admin/processes');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param DestroyProcess $request
     * @param Process $process
     * @throws Exception
     * @return ResponseFactory|RedirectResponse|Response
     */
    public function destroy(DestroyProcess $request, Process $process)
    {
        $process->delete();

        if ($request->ajax()) {
            return response(['message' => trans('brackets/admin-ui::admin.operation.succeeded')]);
        }

        return redirect()->back();
    }

    /**
     * Remove the specified resources from storage.
     *
     * @param BulkDestroyProcess $request
     * @throws Exception
     * @return Response|bool
     */
    public function bulkDestroy(BulkDestroyProcess $request): Response
    {
        DB::transaction(static function () use ($request) {
            collect($request->data['ids'])
                ->chunk(1000)
                ->each(static function ($bulkChunk) {
                    Process::whereIn('id', $bulkChunk)->delete();

                    // TODO your code goes here
                });
        });

        return response(['message' => trans('brackets/admin-ui::admin.operation.succeeded')]);
    }
}
