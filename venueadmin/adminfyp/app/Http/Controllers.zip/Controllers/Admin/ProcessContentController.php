<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ProcessContent\BulkDestroyProcessContent;
use App\Http\Requests\Admin\ProcessContent\DestroyProcessContent;
use App\Http\Requests\Admin\ProcessContent\IndexProcessContent;
use App\Http\Requests\Admin\ProcessContent\StoreProcessContent;
use App\Http\Requests\Admin\ProcessContent\UpdateProcessContent;
use App\Models\ProcessContent;
use Brackets\AdminListing\Facades\AdminListing;
use Exception;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class ProcessContentController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @param IndexProcessContent $request
     * @return array|Factory|View
     */
    public function index(IndexProcessContent $request)
    {
        // create and AdminListing instance for a specific model and
        $data = AdminListing::create(ProcessContent::class)->processRequestAndGet(
            // pass the request with params
            $request,

            // set columns to query
            ['id', 'step_name', 'process_id'],

            // set columns to searchIn
            ['id', 'step_name', 'h1', 'sub_text']
        );

        if ($request->ajax()) {
            if ($request->has('bulk')) {
                return [
                    'bulkItems' => $data->pluck('id')
                ];
            }
            return ['data' => $data];
        }

        return view('admin.process-content.index', ['data' => $data]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @throws AuthorizationException
     * @return Factory|View
     */
    public function create()
    {
        $this->authorize('admin.process-content.create');

        return view('admin.process-content.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreProcessContent $request
     * @return array|RedirectResponse|Redirector
     */
    public function store(StoreProcessContent $request)
    {
        // Sanitize input
        $sanitized = $request->getSanitized();

        // Store the ProcessContent
        $processContent = ProcessContent::create($sanitized);

        if ($request->ajax()) {
            return ['redirect' => url('admin/process-contents'), 'message' => trans('brackets/admin-ui::admin.operation.succeeded')];
        }

        return redirect('admin/process-contents');
    }

    /**
     * Display the specified resource.
     *
     * @param ProcessContent $processContent
     * @throws AuthorizationException
     * @return void
     */
    public function show(ProcessContent $processContent)
    {
        $this->authorize('admin.process-content.show', $processContent);

        // TODO your code goes here
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param ProcessContent $processContent
     * @throws AuthorizationException
     * @return Factory|View
     */
    public function edit(ProcessContent $processContent)
    {
        $this->authorize('admin.process-content.edit', $processContent);


        return view('admin.process-content.edit', [
            'processContent' => $processContent,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateProcessContent $request
     * @param ProcessContent $processContent
     * @return array|RedirectResponse|Redirector
     */
    public function update(UpdateProcessContent $request, ProcessContent $processContent)
    {
        // Sanitize input
        $sanitized = $request->getSanitized();

        // Update changed values ProcessContent
        $processContent->update($sanitized);

        if ($request->ajax()) {
            return [
                'redirect' => url('admin/process-contents'),
                'message' => trans('brackets/admin-ui::admin.operation.succeeded'),
            ];
        }

        return redirect('admin/process-contents');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param DestroyProcessContent $request
     * @param ProcessContent $processContent
     * @throws Exception
     * @return ResponseFactory|RedirectResponse|Response
     */
    public function destroy(DestroyProcessContent $request, ProcessContent $processContent)
    {
        $processContent->delete();

        if ($request->ajax()) {
            return response(['message' => trans('brackets/admin-ui::admin.operation.succeeded')]);
        }

        return redirect()->back();
    }

    /**
     * Remove the specified resources from storage.
     *
     * @param BulkDestroyProcessContent $request
     * @throws Exception
     * @return Response|bool
     */
    public function bulkDestroy(BulkDestroyProcessContent $request) : Response
    {
        DB::transaction(static function () use ($request) {
            collect($request->data['ids'])
                ->chunk(1000)
                ->each(static function ($bulkChunk) {
                    ProcessContent::whereIn('id', $bulkChunk)->delete();

                    // TODO your code goes here
                });
        });

        return response(['message' => trans('brackets/admin-ui::admin.operation.succeeded')]);
    }
}
