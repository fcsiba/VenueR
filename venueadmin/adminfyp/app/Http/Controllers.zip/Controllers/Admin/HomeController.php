<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\SectionContent\BulkDestroySectionContent;
use App\Http\Requests\Admin\SectionContent\DestroySectionContent;
use App\Http\Requests\Admin\SectionContent\IndexSectionContent;
use App\Http\Requests\Admin\SectionContent\StoreSectionContent;
use App\Http\Requests\Admin\SectionContent\UpdateSectionContent;
use App\Models\SectionContent;
use Brackets\AdminListing\Facades\AdminListing;
use Exception;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class HomeController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @param IndexSectionContent $request
     * @return array|Factory|View
     */
    public function index(IndexSectionContent $request)
    {
        // create and AdminListing instance for a specific model and
        // $slider = DB::select('SELECT a.* from section_content a,(select * from sections where section_name="Slider")b where a.sec_id=b.id');
        $section = SectionContent::select('section_content.*')->join('sections', 'sections.id', '=', 'section_content.sec_id')
            ->where('sections.cat_id', '=', '1')->get();
        return view('admin.home.index', ['section' => $section]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @throws AuthorizationException
     * @return Factory|View
     */
    public function create()
    {
        $this->authorize('admin.section-content.create');

        return view('admin.section-content.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreSectionContent $request
     * @return array|RedirectResponse|Redirector
     */
    public function store(StoreSectionContent $request)
    {
        // Sanitize input
        $sanitized = $request->getSanitized();

        // Store the SectionContent
        $sectionContent = SectionContent::create($sanitized);

        if ($request->ajax()) {
            return ['redirect' => url('admin/slider'), 'message' => trans('brackets/admin-ui::admin.operation.succeeded')];
        }

        return redirect('admin/slider');
    }

    /**
     * Display the specified resource.
     *
     * @param SectionContent $sectionContent
     * @throws AuthorizationException
     * @return void
     */
    public function show(SectionContent $sectionContent)
    {
        $this->authorize('admin.section-content.show', $sectionContent);

        // TODO your code goes here
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param SectionContent $sectionContent
     * @throws AuthorizationException
     * @return Factory|View
     */
    public function edit(SectionContent $sectionContent)
    {
        $this->authorize('admin.section-content.edit', $sectionContent);
        $main_txt = "";
        if ($sectionContent->section->section_name == "Steps")
            $main_txt = "Steps";
        else if ($sectionContent->section->section_name == "Sectors")
            $main_txt = "Sectors";
        else
            $main_txt = "Social Media";
        return view('admin.home.edit', [
            'sectionContent' => $sectionContent, 'main_txt' => $main_txt
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateSectionContent $request
     * @param SectionContent $sectionContent
     * @return array|RedirectResponse|Redirector
     */
    public function update(UpdateSectionContent $request, SectionContent $sectionContent)
    {
        // Sanitize input
        $sanitized = $request->getSanitized();

        // Update changed values SectionContent
        $sectionContent->update($sanitized);

        if ($request->ajax()) {
            return [
                'redirect' => url('admin/home'),
                'message' => trans('brackets/admin-ui::admin.operation.succeeded'),
            ];
        }

        return redirect('admin/home');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param DestroySectionContent $request
     * @param SectionContent $sectionContent
     * @throws Exception
     * @return ResponseFactory|RedirectResponse|Response
     */
    public function destroy(DestroySectionContent $request, SectionContent $sectionContent)
    {
        $sectionContent->delete();

        if ($request->ajax()) {
            return response(['message' => trans('brackets/admin-ui::admin.operation.succeeded')]);
        }

        return redirect()->back();
    }

    /**
     * Remove the specified resources from storage.
     *
     * @param BulkDestroySectionContent $request
     * @throws Exception
     * @return Response|bool
     */
    public function bulkDestroy(BulkDestroySectionContent $request): Response
    {
        DB::transaction(static function () use ($request) {
            collect($request->data['ids'])
                ->chunk(1000)
                ->each(static function ($bulkChunk) {
                    SectionContent::whereIn('id', $bulkChunk)->delete();

                    // TODO your code goes here
                });
        });

        return response(['message' => trans('brackets/admin-ui::admin.operation.succeeded')]);
    }
}
