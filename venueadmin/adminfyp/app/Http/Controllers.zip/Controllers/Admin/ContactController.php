<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SurveyUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ContactController extends Controller
{
    public function index()
    {
        // create and AdminListing instance for a specific model and
        // $slider = DB::select('SELECT a.* from section_content a,(select * from sections where section_name="Slider")b where a.sec_id=b.id');
        $contact = DB::select('select * from survey_users where id not in (select user_id from survey) ORDER BY id DESC');
        return view('admin.contact.index', ['contact' => $contact]);
    }
}
