<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Survey\BulkDestroySurvey;
use App\Http\Requests\Admin\Survey\DestroySurvey;
use App\Http\Requests\Admin\Survey\IndexSurvey;
use App\Http\Requests\Admin\Survey\StoreSurvey;
use App\Http\Requests\Admin\Survey\UpdateSurvey;
use App\Models\Survey;
use App\Models\SurveyUser;
use Brackets\AdminListing\Facades\AdminListing;
use Exception;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class SurveyController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @param IndexSurvey $request
     * @return array|Factory|View
     */
    public function index(int $id)
    {
        // create and AdminListing instance for a specific model and
        $response=Survey::where('user_id',$id)->get();
        return view('admin.survey.index', ['response' => $response]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @throws AuthorizationException
     * @return Factory|View
     */
    public function create()
    {
        $this->authorize('admin.survey.create');

        return view('admin.survey.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreSurvey $request
     * @return array|RedirectResponse|Redirector
     */
    public function store(StoreSurvey $request)
    {
        // Sanitize input
        $sanitized = $request->getSanitized();

        // Store the Survey
        $survey = Survey::create($sanitized);

        if ($request->ajax()) {
            return ['redirect' => url('admin/surveys'), 'message' => trans('brackets/admin-ui::admin.operation.succeeded')];
        }

        return redirect('admin/surveys');
    }

    /**
     * Display the specified resource.
     *
     * @param Survey $survey
     * @throws AuthorizationException
     * @return void
     */
    public function show(Survey $survey)
    {
        $this->authorize('admin.survey.show', $survey);

        // TODO your code goes here
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Survey $survey
     * @throws AuthorizationException
     * @return Factory|View
     */
    public function edit(Survey $survey)
    {
        $this->authorize('admin.survey.edit', $survey);


        return view('admin.survey.edit', [
            'survey' => $survey,
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateSurvey $request
     * @param Survey $survey
     * @return array|RedirectResponse|Redirector
     */
    public function update(UpdateSurvey $request, Survey $survey)
    {
        // Sanitize input
        $sanitized = $request->getSanitized();

        // Update changed values Survey
        $survey->update($sanitized);

        if ($request->ajax()) {
            return [
                'redirect' => url('admin/surveys'),
                'message' => trans('brackets/admin-ui::admin.operation.succeeded'),
            ];
        }

        return redirect('admin/surveys');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param DestroySurvey $request
     * @param Survey $survey
     * @throws Exception
     * @return ResponseFactory|RedirectResponse|Response
     */
    public function destroy(DestroySurvey $request, Survey $survey)
    {
        $survey->delete();

        if ($request->ajax()) {
            return response(['message' => trans('brackets/admin-ui::admin.operation.succeeded')]);
        }

        return redirect()->back();
    }

    /**
     * Remove the specified resources from storage.
     *
     * @param BulkDestroySurvey $request
     * @throws Exception
     * @return Response|bool
     */
    public function bulkDestroy(BulkDestroySurvey $request) : Response
    {
        DB::transaction(static function () use ($request) {
            collect($request->data['ids'])
                ->chunk(1000)
                ->each(static function ($bulkChunk) {
                    Survey::whereIn('id', $bulkChunk)->delete();

                    // TODO your code goes here
                });
        });

        return response(['message' => trans('brackets/admin-ui::admin.operation.succeeded')]);
    }
}
